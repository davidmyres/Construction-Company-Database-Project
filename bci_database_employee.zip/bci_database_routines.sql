-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `most_dangerous_projects`
--

DROP TABLE IF EXISTS `most_dangerous_projects`;
/*!50001 DROP VIEW IF EXISTS `most_dangerous_projects`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `most_dangerous_projects` AS SELECT 
 1 AS `project_id`,
 1 AS `type`,
 1 AS `accidents`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `total_coverage`
--

DROP TABLE IF EXISTS `total_coverage`;
/*!50001 DROP VIEW IF EXISTS `total_coverage`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_coverage` AS SELECT 
 1 AS `insurance_co`,
 1 AS `total_coverage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `total_proposals_by_pm`
--

DROP TABLE IF EXISTS `total_proposals_by_pm`;
/*!50001 DROP VIEW IF EXISTS `total_proposals_by_pm`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_proposals_by_pm` AS SELECT 
 1 AS `employee_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `total_proposals`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `extra_benefits`
--

DROP TABLE IF EXISTS `extra_benefits`;
/*!50001 DROP VIEW IF EXISTS `extra_benefits`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `extra_benefits` AS SELECT 
 1 AS `employee_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `job_assignments`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `total_on_equipment`
--

DROP TABLE IF EXISTS `total_on_equipment`;
/*!50001 DROP VIEW IF EXISTS `total_on_equipment`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_on_equipment` AS SELECT 
 1 AS `total_on_equipment`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `maintenance_frequency`
--

DROP TABLE IF EXISTS `maintenance_frequency`;
/*!50001 DROP VIEW IF EXISTS `maintenance_frequency`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `maintenance_frequency` AS SELECT 
 1 AS `equipment_id`,
 1 AS `eqdescription`,
 1 AS `maintenance_frequency`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `stolen_fuel`
--

DROP TABLE IF EXISTS `stolen_fuel`;
/*!50001 DROP VIEW IF EXISTS `stolen_fuel`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `stolen_fuel` AS SELECT 
 1 AS `total_stolen`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `total_on_parts`
--

DROP TABLE IF EXISTS `total_on_parts`;
/*!50001 DROP VIEW IF EXISTS `total_on_parts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_on_parts` AS SELECT 
 1 AS `total_spent_on_parts`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `equipment_on_completed_jobsite`
--

DROP TABLE IF EXISTS `equipment_on_completed_jobsite`;
/*!50001 DROP VIEW IF EXISTS `equipment_on_completed_jobsite`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `equipment_on_completed_jobsite` AS SELECT 
 1 AS `equipment_id`,
 1 AS `eqdescription`,
 1 AS `project_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `most_dangerous_projects`
--

/*!50001 DROP VIEW IF EXISTS `most_dangerous_projects`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `most_dangerous_projects` AS select `a`.`project_id` AS `project_id`,`b`.`TYPE` AS `type`,count(0) AS `accidents` from (`legal` `a` left join `project_description` `b` on((`a`.`project_id` = `b`.`project_id`))) group by `a`.`project_id` order by count(0) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_coverage`
--

/*!50001 DROP VIEW IF EXISTS `total_coverage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_coverage` AS select `insured`.`insurance_co` AS `insurance_co`,round(sum(`insured`.`coverage`),2) AS `total_coverage` from `insured` group by `insured`.`insurance_co` order by sum(`insured`.`coverage`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_proposals_by_pm`
--

/*!50001 DROP VIEW IF EXISTS `total_proposals_by_pm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_proposals_by_pm` AS select `a`.`employee_id` AS `employee_id`,`b`.`first_name` AS `first_name`,`b`.`last_name` AS `last_name`,count(0) AS `total_proposals` from (`proposals` `a` left join `employee` `b` on((`a`.`employee_id` = `b`.`employee_id`))) group by `a`.`employee_id` order by `total_proposals` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `extra_benefits`
--

/*!50001 DROP VIEW IF EXISTS `extra_benefits`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `extra_benefits` AS select `a`.`employee_id` AS `employee_id`,`b`.`first_name` AS `first_name`,`b`.`last_name` AS `last_name`,count(0) AS `job_assignments` from (`project_employee` `a` left join `employee` `b` on((`a`.`employee_id` = `b`.`employee_id`))) group by `a`.`employee_id` having (count(0) > 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_on_equipment`
--

/*!50001 DROP VIEW IF EXISTS `total_on_equipment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_on_equipment` AS select sum(`equipment`.`PURCHASE_PRICE`) AS `total_on_equipment` from `equipment` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `maintenance_frequency`
--

/*!50001 DROP VIEW IF EXISTS `maintenance_frequency`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `maintenance_frequency` AS select `a`.`equipment_id` AS `equipment_id`,`b`.`EQDESCRIPTION` AS `eqdescription`,count(0) AS `maintenance_frequency` from (`maintinence` `a` left join `equipment` `b` on((`a`.`equipment_id` = `b`.`equipment_id`))) group by `a`.`equipment_id` order by `maintenance_frequency` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stolen_fuel`
--

/*!50001 DROP VIEW IF EXISTS `stolen_fuel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `stolen_fuel` AS select (sum(`fuel`.`amount`) * 3.14) AS `total_stolen` from `fuel` where (`fuel`.`employee_id` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_on_parts`
--

/*!50001 DROP VIEW IF EXISTS `total_on_parts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_on_parts` AS select sum((`b`.`cost` * `a`.`Quantity`)) AS `total_spent_on_parts` from (`invoice` `a` left join `parts_orders` `b` on((`a`.`item_id` = `b`.`item_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `equipment_on_completed_jobsite`
--

/*!50001 DROP VIEW IF EXISTS `equipment_on_completed_jobsite`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `equipment_on_completed_jobsite` AS select `a`.`equipment_id` AS `equipment_id`,`b`.`EQDESCRIPTION` AS `eqdescription`,`a`.`project_id` AS `project_id` from ((select `a`.`equipment_id` AS `equipment_id`,`b`.`project_id` AS `project_id` from (`project_equipment` `a` left join `project_description` `b` on((`a`.`project_id` = `b`.`project_id`))) where (`b`.`COMPLETED` = 1)) `a` left join `equipment` `b` on((`a`.`equipment_id` = `b`.`equipment_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'bci_database'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:08
