-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `parts_orders`
--

DROP TABLE IF EXISTS `parts_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parts_orders` (
  `item_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `manufacturer` varchar(30) NOT NULL,
  `cost` decimal(6,2) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts_orders`
--

LOCK TABLES `parts_orders` WRITE;
/*!40000 ALTER TABLE `parts_orders` DISABLE KEYS */;
INSERT INTO `parts_orders` VALUES (1,'Wheel','Flashset',40.00),(2,'Air compressor attachment set','Twinte',300.00),(3,'Shovel','Mybuzz',15.00),(4,'Air Filter','Trunyx',75.00),(5,'Lift Cylinder','Demivee',200.00),(6,'Spark Plug','Meedoo',8.00),(7,'Synthetic Diesel Oil, 5 gal.','Pixope',180.00),(8,'Excavator Bucket','Oodoo',1681.80),(9,'Thermostat Guage','Miboo',3145.46),(10,'Fuel Cap','Divape',40.00),(11,'Windshield','InnoZ',2035.06),(12,'2-inch Screws','Kwideo',0.50),(13,'Fuel Pump','Gabspot',9808.09),(14,'Cat Rubber Track','Zoomzone',7380.91),(15,'Caterpillar Track Sprocket','Edgewire',5351.89),(16,'Radio','Innojam',125.00),(17,'CAT Track Idler Wheel','Aimbu',8151.99),(18,'CAT Bottom Roller','Vimbo',5453.35),(19,'Oil Filter','Realcube',30.00),(20,'Pipe Wrench','Fivechat',38.00),(21,'pH test strips','Digitube',35.00),(22,'grease gun','Blogpad',21.00),(23,'air compressor','Jabbersphere',9854.86),(24,'crescent wrench','Gigashots',7.00),(25,'Ramp','Wordtune',800.00),(26,'fabrication set','Tagpad',7542.05),(27,'bolt cutters','Fivechat',65.00),(28,'scissor jack','Vimbo',951.92),(29,'tire wrench','Roombo',62.00),(30,'drill','Photojam',360.00);
/*!40000 ALTER TABLE `parts_orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:08
