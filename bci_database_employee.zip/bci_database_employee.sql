-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `DEPARTMENT` varchar(45) NOT NULL,
  `SALARY` int NOT NULL,
  `PHONE_NUMBER` char(12) NOT NULL,
  `ADDRESS` varchar(60) NOT NULL,
  `CITY` varchar(45) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Stormi','Currell','Chief Executive Officer',250000,'684-472-2775','Room 966','Banjaranyar'),(2,'Hiram','Lowers','Chief Financial Officer',145000,'699-154-2751','Room 446','Tongzha'),(3,'Roman','Bodycombe','Human Resources',75000,'253-708-7389','Suite 22','Daloa'),(4,'Feliza','Ruddlesden','Safety',85000,'768-202-6297','Suite 16','Nong Phok'),(5,'Charlean','Letherbury','Project Manager',115000,'250-471-0867','PO Box 88576','Saint-Maixent-l\'École'),(6,'Laverna','Skough','Project Manager',112000,'498-414-5263','Suite 85','G‘azalkent'),(7,'Hubie','Bywater','Project Manager',111000,'340-645-0784','Suite 74','Leskovec pri Krškem'),(8,'Cristie','Abercrombie','Estimator',92000,'223-494-3666','Suite 9','Egvekinot'),(9,'Fremont','Leathes','Estimator',94000,'339-196-8111','Room 1943','San Pedro'),(10,'Bethany','Sumshon','Accounting',120000,'821-853-5478','Room 1831','Táriba'),(11,'Upton','Hastelow','Accounting',122000,'301-255-3244','17th Floor','Randuagung'),(12,'Layney','McGilvray','Shop',80000,'190-459-6939','Room 1087','Shuangxikou'),(13,'Dulci','Mudge','Shop',77000,'389-401-4338','Suite 96','?om?a'),(14,'Silvio','Gyves','Shop',76000,'336-369-7052','3rd Floor','Castelo'),(15,'Gayle','Carwardine','Shop',76000,'595-759-5019','17th Floor','Penha'),(16,'Agata','Dimelow','Shop',78000,'672-280-6998','PO Box 7947','Frashër'),(17,'Tuckie','Axtens','Information Technology',160000,'310-519-4375','PO Box 85023','Roches Noire'),(18,'Marybeth','Haney`','Foreman',60000,'565-435-8161','11th Floor','Karanglincak'),(19,'Rolf','McAw','Foreman',62000,'729-927-9001','Suite 55','Casal da Anja'),(20,'Broddy','Withinshaw','Foreman',63000,'585-486-0021','Apt 935','Xifengshan'),(21,'Carce','Sheard','Foreman',61000,'493-936-6359','Room 1479','K?nan'),(22,'Deeann','Larby','Foreman',60000,'907-820-7343','Apt 1152','El Zulia'),(23,'Fayette','Petrescu','Foreman',61000,'203-741-2029','Apt 1310','Épinal'),(24,'Ikey','Bearn','Operator',51166,'163-466-5395','Room 568','Jiangfang'),(25,'Florina','Willcocks','Operator',52306,'530-683-7134','17th Floor','Xiongshan'),(26,'Gerianna','Janway','Operator',58924,'802-580-4274','Room 306','Paris La Défense'),(27,'Gerik','Imlacke','Operator',50782,'194-404-4094','Apt 1969','Ubay'),(28,'Fredra','Joscelyn','Operator',56521,'959-807-3994','Apt 1417','Tarbes'),(29,'Moina','Beckingham','Operator',57490,'755-656-9376','PO Box 7054','Motrico'),(30,'Carroll','Donnelly','Operator',58941,'497-199-7345','Suite 46','Saint-Priest-en-Jarez'),(31,'Reyna','De Ruggiero','Operator',59063,'435-854-8932','PO Box 84874','Changqing'),(32,'Chilton','Goggan','Operator',58502,'481-238-9301','Room 1939','Panamá'),(33,'Natale','Burchfield','Operator',55570,'357-372-9315','3rd Floor','Malabugas'),(34,'Moina','Crass','Operator',54306,'885-490-4916','Apt 110','Joal-Fadiout'),(35,'Corney','Pollington','Operator',50677,'100-124-5445','PO Box 27181','Riga'),(36,'Suzann','Pechan','Operator',59833,'816-948-5388','PO Box 77585','Bothaville'),(37,'Sayer','Maddox','Operator',52706,'465-419-5377','Apt 1949','Bajera'),(38,'Paulie','Mullard','Operator',55898,'435-945-4108','Apt 1007','Bobon'),(39,'Cati','Elcum','Operator',53923,'125-950-4573','Apt 1761','P?o?sk'),(40,'Raine','Dowker','Operator',54795,'746-136-6503','Room 1283','Magaria');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
