-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `invoice_no` smallint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` smallint unsigned NOT NULL,
  `employee_id` smallint unsigned NOT NULL,
  `card_number` char(19) NOT NULL,
  `Date_Ordered` text NOT NULL,
  `Quantity` int NOT NULL,
  `Status` varchar(15) NOT NULL,
  PRIMARY KEY (`invoice_no`),
  KEY `fk_employee_invemp_idx` (`employee_id`),
  KEY `fk_item_invit_idx` (`item_id`),
  CONSTRAINT `fk_employee_invemp` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_item_invit` FOREIGN KEY (`item_id`) REFERENCES `parts_orders` (`item_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,19,14,'2479 2470 9075 7217','2024-02-27',1,'Pending'),(2,30,13,'4312 3876 5829 2467','2022-09-14',1,'Arrived'),(3,7,15,'9374 9183 5825 4482','2024-11-22',2,'Pending'),(4,14,14,'2479 2470 9075 7217','2019-01-30',1,'Arrived'),(5,3,14,'2479 2470 9075 7217','2021-07-14',1,'Returned'),(6,27,14,'2479 2470 9075 7217','2021-10-16',3,'Cancelled'),(7,15,12,'7237 2579 1369 8264','2024-11-04',5,'Arrived'),(8,11,13,'4312 3876 5829 2467','2021-17-19',1,'Arrived'),(9,19,15,'9374 9183 5825 4482','2020-10-09',1,'Returned'),(10,12,14,'2479 2470 9075 7217','2021-03-07',1,'Arrived'),(11,10,15,'9374 9183 5825 4482','2021-04-07',2,'Returned'),(12,26,13,'4312 3876 5829 2467','2023-09-04',3,'Arrived'),(13,9,13,'4312 3876 5829 2467','2020-11-13',1,'Canelled'),(14,1,14,'2479 2470 9075 7217','2022-02-10',2,'Arrived'),(15,25,13,'4312 3876 5829 2467','2021-03-18',1,'Returned'),(16,27,15,'9374 9183 5825 4482','2024-12-07',1,'Pending'),(17,19,15,'9374 9183 5825 4482','2024-12-15',1,'Pending'),(18,30,13,'4312 3876 5829 2467','2021-09-14',4,'Pending'),(19,1,14,'2479 2470 9075 7217','2024-10-12',1,'Cancelled'),(20,12,13,'4312 3876 5829 2467','2024-12-17',2,'Pending'),(21,30,13,'4312 3876 5829 2467','2019-12-06',2,'Arrived');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
