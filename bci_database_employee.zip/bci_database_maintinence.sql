-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `maintinence`
--

DROP TABLE IF EXISTS `maintinence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintinence` (
  `job_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `Description` text NOT NULL,
  `Service Date` text NOT NULL,
  `equipment_id` smallint unsigned NOT NULL,
  `employee_id` smallint unsigned NOT NULL,
  `Hour Reading 4000 max` int NOT NULL,
  `Odometer Readings 10000 Max` int NOT NULL,
  PRIMARY KEY (`job_id`),
  KEY `fk_employees_mainemp_idx` (`employee_id`),
  KEY `fk_equipment_maineq_idx` (`equipment_id`),
  CONSTRAINT `fk_employees_mainemp` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_equipment_maineq` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintinence`
--

LOCK TABLES `maintinence` WRITE;
/*!40000 ALTER TABLE `maintinence` DISABLE KEYS */;
INSERT INTO `maintinence` VALUES (1,'Engine Tuning','3/7/2023',6,13,980,2450),(2,'Routine Check','5/21/2023',1,14,3959,9897),(3,'Tire Rotation','5/29/2023',12,15,543,1357),(4,'Routine Check','7/3/2023',22,14,1275,3187),(5,'Track Repair','8/14/2023',6,13,3404,8510),(6,'Electrical','10/4/2023',20,16,1492,3730),(7,'Routine Check','12/29/2023',24,12,2019,5047),(8,'Filter Replacement','1/7/2024',3,16,2852,7130),(9,'Routine Check','1/9/2024',2,15,3296,8240),(10,'Diagnostics','2/27/2024',31,13,2698,6746),(11,'Cooling System','4/23/2024',29,12,3111,7777),(12,'Electrical','5/1/2024',6,15,2313,5782),(13,'Routine Check','6/17/2024',4,13,1041,2603),(14,'Diagnostics','8/28/2024',27,14,3580,8950),(15,'Cooling System','10/8/2024',29,15,331,827),(16,'Routine Check','11/27/2024',15,13,517,1292);
/*!40000 ALTER TABLE `maintinence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
