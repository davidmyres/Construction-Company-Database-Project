-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `legal`
--

DROP TABLE IF EXISTS `legal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal` (
  `case_no` smallint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` smallint unsigned NOT NULL,
  `policy_no` smallint unsigned NOT NULL,
  `deputy_id` smallint unsigned NOT NULL,
  `county_commisioner` varchar(25) NOT NULL,
  `fine` double NOT NULL,
  `estimated_damages` int NOT NULL,
  `violated_statute` varchar(10) NOT NULL,
  `description` varchar(20) NOT NULL,
  PRIMARY KEY (`case_no`),
  KEY `fk_project_legproj_idx` (`project_id`),
  KEY `fk_policyno_legins_idx` (`policy_no`),
  CONSTRAINT `fk_policyno_legins` FOREIGN KEY (`policy_no`) REFERENCES `insured` (`policy_number`),
  CONSTRAINT `fk_project_legproj` FOREIGN KEY (`project_id`) REFERENCES `project_description` (`project_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legal`
--

LOCK TABLES `legal` WRITE;
/*!40000 ALTER TABLE `legal` DISABLE KEYS */;
INSERT INTO `legal` VALUES (1,3,10,143,'r. smith',7833,39165,'1.4.10','Oil Leak'),(2,4,11,185,'p. jackson',27112,135560,'1.5.7','Injured Pedestrian'),(3,1,9,186,'d. myres',2820.4,14102,'1.5.7','Injured Pedestrian'),(4,5,8,104,'h. winters',4246,21230,'1.4.10','Oil Leak'),(5,2,14,129,'t. walker',9319.8,46599,'5.9.1','Threat to Wildlife'),(6,5,21,168,'m. neuman',24379.6,121898,'1.5.7','Injured Pedestrian'),(7,5,1,146,'r. goyle',21913.8,109569,'1.4.10','Oil Leak'),(8,2,6,173,'f. johnson',22194.2,110971,'1.5.7','Injured Pedestrian'),(9,2,16,199,'h. winters',29956.4,149782,'1.5.7','Injured Pedestrian'),(10,3,1,170,'e. stanz',21413,107065,'1.5.7','Injured Pedestrian'),(11,2,5,160,'r. smith',21185.6,105928,'1.4.10','Oil Leak'),(12,3,21,177,'t. walker',18223.6,91118,'4.7.6','Foreman Not Present'),(13,1,18,103,'d. myres',3330.8,16654,'5.8.2','Equipment on Highway'),(14,1,17,122,'m. neuman',1385,6925,'5.9.1','Threat to Wildlife'),(15,1,27,161,'b. andre',19673.8,98369,'1.5.7','Injured Pedestrian'),(16,1,3,175,'p. jackson',13435.6,67178,'5.8.2','Equipment on Highway'),(17,5,28,170,'e. stanz',4654,23270,'5.8.2','Equipment on Highway'),(18,5,7,133,'e. stanz',13578.6,67893,'5.9.1','Threat to Wildlife'),(19,4,4,202,'f. johnson',28246.4,141232,'6.0.1','Unregistered to Dig'),(20,3,8,185,'g. nicks',15795,78975,'1.5.7','Injured Pedestrian'),(21,1,12,169,'r. goyle',808.4,4042,'5.9.1','Threat to Wildlife'),(22,4,17,171,'h. winters',26431,132155,'5.8.2','Equipment on Highway'),(23,2,9,235,'m. fisk',29803,149015,'4.7.6','Foreman Not Present'),(24,3,23,214,'j. tyler',9489.6,47448,'6.0.1','Unregistered to Dig'),(25,2,2,140,'s. ilne',23223.2,116116,'1.5.7','Injured Pedestrian'),(26,2,11,156,'b. andre',25652.8,128264,'1.5.7','Injured Pedestrian'),(27,2,29,210,'j. tyler',3352.6,16763,'6.0.1','Unregistered to Dig'),(28,2,8,116,'d. myres',2020.6,10103,'5.9.1','Threat to Wildlife'),(29,5,5,123,'f. johnson',17493.2,87466,'1.4.10','Oil Leak'),(30,2,12,200,'r. smith',8496.4,42482,'5.8.2','Equipment on Highway');
/*!40000 ALTER TABLE `legal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
