-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insured`
--

DROP TABLE IF EXISTS `insured`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insured` (
  `policy_number` smallint unsigned NOT NULL AUTO_INCREMENT,
  `equipment_id` smallint unsigned NOT NULL,
  `expiration_date` text NOT NULL,
  `coverage` double NOT NULL,
  `insurance_co` text NOT NULL,
  `company_address` text NOT NULL,
  `company_city` text NOT NULL,
  PRIMARY KEY (`policy_number`),
  KEY `fk_equipment_inseq_idx` (`equipment_id`),
  CONSTRAINT `fk_equipment_inseq` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insured`
--

LOCK TABLES `insured` WRITE;
/*!40000 ALTER TABLE `insured` DISABLE KEYS */;
INSERT INTO `insured` VALUES (1,3,'2/6/2026',90099.78,'Royal Insurance','3900 Bethel Dr.','St. Paul'),(2,10,'3/9/2026',77350.58,'Royal Insurance','3900 Bethel Dr.','St. Paul'),(3,7,'8/16/2026',53558.31,'Royal Insurance','3900 Bethel Dr.','St. Paul'),(4,31,'7/30/2026',10182.18,'Royal Insurance','3900 Bethel Dr.','St. Paul'),(5,33,'12/5/2026',30675.43,'Royal Insurance','3900 Bethel Dr.','St. Paul'),(6,8,'10/17/2026',27952.93,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(7,9,'11/13/2026',41467.67,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(8,23,'1/31/2026',82354.25,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(9,32,'3/26/2026',55518.17,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(10,36,'2/9/2026',77168.12,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(11,27,'5/2/2026',64049.2,'Piper Insurance','1536 Hewitt Ave.','St. Paul'),(12,20,'3/3/2026',82607.69,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(13,26,'2/18/2026',11492.32,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(14,34,'11/27/2026',92130.93,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(15,19,'2/7/2026',29132.91,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(16,1,'5/15/2026',12735.85,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(17,28,'7/26/2026',59235.55,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(18,6,'10/22/2026',62255.7,'Ole Insurance','1520 St Olaf Ave.','Northfield'),(19,30,'10/9/2026',13778.57,'Cobber Insurance','901 8th St. S','Moorhead'),(20,4,'3/12/2026',84021.84,'Cobber Insurance','901 8th St. S','Moorhead'),(21,2,'4/2/2026',87570.46,'Cobber Insurance','901 8th St. S','Moorhead'),(22,24,'1/3/2026',35032.39,'Cobber Insurance','901 8th St. S','Moorhead'),(23,25,'1/12/2026',97816.75,'Cobber Insurance','901 8th St. S','Moorhead'),(24,5,'7/17/2026',97998.88,'Gustie Insurance','800 W College Ave.','St. Peter'),(25,37,'5/1/2026',98329.94,'Gustie Insurance','800 W College Ave.','St. Peter'),(26,35,'11/29/2026',39147.59,'Gustie Insurance','800 W College Ave.','St. Peter'),(27,29,'11/7/2026',24441.39,'Gustie Insurance','800 W College Ave.','St. Peter'),(28,22,'12/9/2026',78058.73,'Gustie Insurance','800 W College Ave.','St. Peter'),(29,18,'9/5/2026',16660.87,'Gustie Insurance','800 W College Ave.','St. Peter'),(30,21,'8/17/2026',41777.36,'Gustie Insurance','800 W College Ave.','St. Peter');
/*!40000 ALTER TABLE `insured` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
