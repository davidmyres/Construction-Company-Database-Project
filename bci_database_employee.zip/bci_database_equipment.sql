-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: bci_database
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `equipment_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `EQDESCRIPTION` varchar(45) NOT NULL,
  `MAKE` varchar(45) NOT NULL,
  `MODEL` varchar(45) NOT NULL,
  `YEAR` int NOT NULL,
  `PURCHASE_PRICE` int NOT NULL,
  `PURCHASE_DATE` char(10) NOT NULL,
  `HEIGHT` int NOT NULL,
  `WIDTH` int NOT NULL,
  `LENGTH` int NOT NULL,
  `WEIGHT` int NOT NULL,
  `STATUS` varchar(45) NOT NULL,
  `SERIAL_NUMBER` varchar(60) NOT NULL,
  `TITLE` int NOT NULL,
  `TOTAL_LEINS` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`equipment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'DOZER','komatsu','d65px-18',2007,76000,'12/16/2007',12,10,16,24640,'SERVICED','jfgwefq34',0,''),(2,'DOZER','liebherr','pr 726',2010,78000,'2/26/2010',11,10,16,23458,'ACTIVE','dfgr34q87f',0,''),(3,'DOZER','john deere','d5i',2021,72000,'5/13/2022',11,10,16,22826,'ACTIVE','iwf4h7qf',0,''),(4,'DOZER','john deere','d7i',2012,72000,'8/14/2013',9,10,16,28082,'ACTIVE','47qf9hd',0,''),(5,'ROLLER','komatsu','jv100wa-2',2015,65000,'8/4/2016',11,6,10,7949,'SOLD','947rhq',0,''),(6,'ROLLER','komatsu','jv100wa-2',1997,65000,'6/15/1998',8,6,10,8344,'SERVICED','4t5gre4t5y',0,''),(7,'BACKHOE','caterpillar','cat 301.5',2007,210000,'11/17/2008',12,5,8,8692,'MISSING','4trew',0,''),(8,'BACKHOE','komatsu','pc130lc-11',2008,175000,'11/23/2009',32,7,15,44831,'ACTIVE','r56ytrew',0,''),(9,'BACKHOE','caterpillar','cat 395',1998,300000,'5/23/1999',40,8,16,76405,'ACTIVE','fhytgfdrt',0,''),(10,'CRANE','manitowoc','lattice crawler',2022,1600000,'5/28/2022',120,12,20,435280,'ACTIVE','ghuy65432wdr5y',0,''),(11,'GENERATOR','generac','g5',2024,5000,'7/4/2025',4,4,4,697,'ACTIVE','rter6gw45q43',0,''),(12,'GENERATOR','generac','g5',2024,5000,'4/6/2024',4,4,4,1259,'SERVICED','546ey45yy',0,''),(13,'GENERATOR','generac','g5',2023,5000,'3/26/2023',4,4,4,1035,'SOLD','53576435t45uyr',0,''),(14,'GENERATOR','cummins','c3',2023,5000,'8/4/2024',4,4,4,892,'ACTIVE','t5gh6rgge5g',0,''),(15,'GENERATOR','cummins','c3',2023,5000,'6/21/2023',4,4,4,706,'MISSING','g456rehr576',0,''),(16,'GENERATOR','cummins','c3',2023,5000,'9/22/2024',4,4,4,700,'ACTIVE','wg6w65rhw6',0,''),(17,'GENERATOR','yamaha','y1',2022,10000,'10/1/2023',4,4,4,930,'ACTIVE','btw6rbw',0,''),(18,'TRAILER','Reitnour','flatbed',1989,36000,'5/7/1990',6,10,25,5974,'ACTIVE','h645y',1,'0'),(19,'TRAILER','Reitnour','gooseneck',2000,45000,'5/24/2001',3,13,21,2909,'ACTIVE','ert54ey6t',1,'0'),(20,'TRAILER','Trail King','lowboy',2002,52000,'5/8/2003',6,9,20,3706,'SERVICED','e5yw45y4',1,'0'),(21,'TRAILER','Trail King','lowboy',2010,52000,'1/3/2011',4,13,33,4757,'MISSING','y6eu56w5y',1,'1'),(22,'TRAILER','Towmaster','flatbed',2004,24000,'1/13/2005',3,11,34,3337,'ACTIVE','w5uwuw5y',1,'1'),(23,'TRAILER','Towmaster','gooseneck',2013,47000,'4/9/2014',7,8,34,4692,'ACTIVE','5egeh75ew',1,'1'),(24,'TRAILER','Towmaster','stepdeck',2018,54000,'8/22/2019',5,9,34,3098,'SERVICED','ghuk8iu65',1,'1'),(25,'TRAILER','Towmaster','stepdeck',2016,34000,'12/28/2016',3,10,33,2325,'ACTIVE','kjhgtre34567',1,'1'),(26,'TRAILER','Towmaster','flatbed',1995,29000,'2/19/1996',3,9,29,1591,'ACTIVE','jhgfdew4567',1,'1'),(27,'TRAILER','Towmaster','lowboy',1998,30000,'1/23/1998',4,10,22,1788,'ACTIVE','87654ewrtyu',1,'1'),(28,'PICKUP','ford','f-250',2009,65000,'11/6/2010',8,7,14,2959,'ACTIVE','87654erghy',1,'1'),(29,'PICKUP','ford','f-250',2012,65000,'8/21/2012',8,7,14,2556,'ACTIVE','9876th',1,'1'),(30,'PICKUP','ram','1500',2017,65000,'9/22/2017',8,7,14,1950,'ACTIVE','876trfghg',1,'1'),(31,'PICKUP','chevrolet','silverado',2020,65000,'10/8/2020',8,7,14,2185,'SERVICED','fghjuy56',1,'1'),(32,'PICKUP','chevrolet','silverado',2021,65000,'5/1/2021',8,7,14,2374,'ACTIVE','56trg',1,'1'),(33,'DUMP TRUCK','volvo','vhd 300 ab',1999,112000,'7/28/2000',12,12,22,34201,'ACTIVE','fghtr56',1,'1'),(34,'DUMP TRUCK','volvo','vhd 300 ab',2007,133000,'10/11/2008',13,12,22,66939,'ACTIVE','hbthujki98',1,'1'),(35,'DUMP TRUCK','freightliner','m2 106',2009,142000,'9/24/2010',10,12,20,40972,'MISSING','yhgfder5',1,'1'),(36,'DUMP TRUCK','freightliner','m2 106',2014,151000,'3/5/2014',10,12,21,42574,'SOLD','sdfgytrew234',1,'1'),(37,'DUMP TRUCK','freightliner','m2 106',2022,160000,'4/25/2022',8,12,22,26578,'ACTIVE','vbhnjkuyt6',1,'1');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 17:02:07
